package com.demo.dao;

import com.demo.bean.Person;
import com.demo.bean.Product;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DaoOperationImpl implements DaoOperations{

    public Person findPerson(String name,String pass) throws SQLException {
        Connection c = DButils.getConnectionMy();
        try {
            PreparedStatement ps = c.prepareStatement("select * from login where username = ? and password = ? ");
            ps.setString(1,name);
            ps.setString(2,pass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
            	LocalDate date = rs.getDate(3).toLocalDate();
                return new Person(rs.getString(1),rs.getString(2),date,rs.getString(4));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return null;
    }


    public boolean addProduct(Product product) {
        if (product != null){
            try {
                Connection c = DButils.getConnectionMy();
                PreparedStatement pr = c.prepareStatement("insert into productJdbc(pName,quantity,price,discount,description) values(?,?,?,?,?)");
                pr.setString(1,product.getpName());
                pr.setInt(2,product.getQuantity());
                pr.setInt(3,product.getPrice());
                pr.setDouble(4,product.getDiscount());
                pr.setString(5,product.getDescription());

                int rs = pr.executeUpdate();
                if (rs > 0) {
                    return true;
                }else
                    return false;
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return false;
    }

    public List<Product> showAll() {
        List<Product> ans = new ArrayList<>();
    	try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("select * from productJdbc");

            ResultSet rs = pr.executeQuery();
            while (rs.next()){
            	Product p = new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4) ,rs.getDouble(5)*100,rs.getString(6), rs.getDouble(7));
            	ans.add(p);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return ans;
    }

    public boolean deleteItem(int id) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("delete from productJdbc where pid=?");
            pr.setInt(1,id);
            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }


    public List<Product> sortByPrice() {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("select * from productJdbc order by total_price");

            ResultSet rs = pr.executeQuery();
            while (rs.next()){
                System.out.println("Product id : " + rs.getInt(1) +", productName :  " +rs.getString(2)+ ", quantity_left ; " + rs.getInt(3) + ", discount : " + rs.getDouble(5)*100+"%, it is : " + rs.getString(6) + ", total price : " + rs.getDouble(7));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
		return null;
	
    }


    public boolean updateQuantity(int pid, int qunt) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("update productJdbc set quantity = ? where pid = ? ");
            pr.setInt(1,qunt);
            pr.setInt(2,pid);
            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }


    public boolean updatePrice(int pid, int qunt) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("update productJdbc set price = ? where pid = ? ");
            pr.setInt(1,qunt);
            pr.setInt(2,pid);
            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }


    public boolean updateDiscount(int pid, double qunt) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("update productJdbc set discount = ? where pid = ? ");
            pr.setDouble(1,qunt);
            pr.setInt(2,pid);
            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }


    public boolean addNewUser(Person p) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("insert into login values(?,?,?,?);");
            Date date = Date.valueOf(p.getDob());
            pr.setString(1,p.getName());
            pr.setString(2,p.getPass());
            pr.setDate(3,date);
            pr.setString(4,p.getRole());

            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean addToBucket(String userName, int pid) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("insert into bucket values(?,?);");
            pr.setString(1,userName);
            pr.setInt(2,pid);
            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }


    public void sortByName() {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("select * from productJdbc order by pName");

            ResultSet rs = pr.executeQuery();
            while (rs.next()){
                System.out.println("Product id : " + rs.getInt(1) +", productName :  " +rs.getString(2)+ ", quantity_left ; " + rs.getInt(3) + ", discount : " + rs.getDouble(5)*100+"%, it is : " + rs.getString(6) + ", total price : " + rs.getDouble(7));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public boolean removeFromBucket(String name, int id) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr = c.prepareStatement("delete from bucket where username = ? and productid = ? limit 1");
            pr.setString(1,name);
            pr.setInt(2,id);
            int rs = pr.executeUpdate();
            if (rs > 0) return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public List<Product> showBucket(String user) {
        List<Product> cart = new ArrayList<>();
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr1 = c.prepareStatement("select * from login where username = ? ");
            pr1.setString(1,user);
            ResultSet ans = pr1.executeQuery();
            if (ans.next()){
                PreparedStatement pr = c.prepareStatement(" select  * from productJdbc where pid in (select productId from bucket where userName = ? ) order by pid;");
                PreparedStatement quant = c.prepareStatement("select productId,count(productId) from bucket where userName = ? group by productId order by productId");
                quant.setString(1, user);
                pr.setString(1,user);
                ResultSet qt = quant.executeQuery();
                ResultSet rs = pr.executeQuery();
                while (rs.next() && qt.next()){
                	Product p = new Product(rs.getInt(1),rs.getString(2),rs.getInt(4),rs.getString(6),rs.getDouble(7),qt.getInt(2));
                	cart.add(p);
                }
            }else{
                System.out.println("Something went wrong");
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
        return cart;
    }

    public boolean changeUserName(String user, String pass, String newUser) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr1 = c.prepareStatement("select * from login where username = ? and password = ? ");
            pr1.setString(1, user);
            pr1.setString(2, pass);
            ResultSet ans = pr1.executeQuery();
            if (ans.next()) {
                PreparedStatement pr = c.prepareStatement("update login set username = ? where username = ? ");
                PreparedStatement pr2 = c.prepareStatement("update bucket set username = ? where username = ? ");
                pr.setString(1,newUser);
                pr.setString(2,user);
                pr2.setString(1,newUser);
                pr2.setString(2,user);
                int tb1 = pr.executeUpdate();
                int tb2 = pr2.executeUpdate();
                if (tb1 > 0 && tb2 > 0) return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;

    }

    public boolean changePassword(String user, String pass, String newUser) {
        try {
            Connection c = DButils.getConnectionMy();
            PreparedStatement pr1 = c.prepareStatement("select * from login where username = ? and password = ? ");
            pr1.setString(1, user);
            pr1.setString(2, pass);
            ResultSet ans = pr1.executeQuery();
            if (ans.next()) {
                PreparedStatement pr = c.prepareStatement("update login set password = ? where username = ? ");
                pr.setString(1,newUser);
                pr.setString(2,user);
                int tb1 = pr.executeUpdate();
                if (tb1 > 0) return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }
}