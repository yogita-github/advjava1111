package com.demo.servlets;

import java.io.IOException;

import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UpdatePrice extends HttpServlet{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		ProductService ps = new ProductServiceImpl();
		boolean res = ps.updatePrice();
		RequestDispatcher rd = req.getRequestDispatcher("showProduct.jsp");
		rd.forward(req, resp);	
	}

}
