package com.demo.service;

import java.util.List;

import com.demo.bean.Product;

public interface UserService {

    void showAllProducts();

    boolean addToBucket(String userName,int pid);

    void sortByPrice();

    void sortByName();

    boolean removeFromBucket(String s,int i);

    boolean changeUserName();

    List<Product> showMyBucket(String u);

    boolean changePassword();
}
