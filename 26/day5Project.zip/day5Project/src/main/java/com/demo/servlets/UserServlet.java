package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import com.demo.dao.DaoOperationImpl;
import com.demo.dao.DaoOperations;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserServlet extends HttpServlet{
	public void doPost(HttpServletRequest request ,HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter pr = response.getWriter();
		String val = request.getParameter("productAction");
	    Scanner sc = new Scanner(System.in);
	    DaoOperations daoOperations = new DaoOperationImpl();
	    
		switch (val) {
		case "addToCart": {
			RequestDispatcher rd = request.getRequestDispatcher("userProd");
			rd.forward(request, response);
			break;
		}
		case "showCart":{
			RequestDispatcher rd = request.getRequestDispatcher("showCart");
			rd.forward(request, response);	
			break;
		}
		case "sort":{
			RequestDispatcher rd = request.getRequestDispatcher("sortByPrice.jsp");
			rd.forward(request, response);
			break;
		}
		case "removeFromCart":{
			RequestDispatcher rd = request.getRequestDispatcher("showCart");
			request.setAttribute("val", 1);
			rd.include(request, response);
			
			RequestDispatcher rd1 = request.getRequestDispatcher("deleteFromCart.jsp");
			rd1.forward(request, response);
			break;
		}
		case "updatePrice":{
			RequestDispatcher rd = request.getRequestDispatcher("updatePrice.jsp");
			rd.forward(request,response);
			break;
		}
		case "addDiscount":{
			RequestDispatcher rd = request.getRequestDispatcher("addDiscount.jsp");
			rd.forward(request,response);
			break;
		}
		case "showAll":{
			RequestDispatcher rd = request.getRequestDispatcher("/product");
			rd.forward(request, response);	
			break;
		}
		default:
			RequestDispatcher rd = request.getRequestDispatcher("admin.html");
			rd.forward(request, response);
			break;
		}
		
	}

}
