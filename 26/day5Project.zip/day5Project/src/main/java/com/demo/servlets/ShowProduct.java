package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ShowProduct extends HttpServlet{
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		ProductService ps = new ProductServiceImpl();
		List<Product> ans = ps.showAll();
		req.setAttribute("products", ans);
		RequestDispatcher rd = req.getRequestDispatcher("showProduct.jsp");
		rd.forward(req, resp);
	}
	

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
