package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import com.demo.bean.Person;
import com.demo.service.LoginService;
import com.demo.service.LoginServiceImpl;
import com.mysql.cj.Session;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class Login extends HttpServlet {
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		res.setContentType("text/html");
		PrintWriter pr = res.getWriter();
		String uname = req.getParameter("username");
		String pass = req.getParameter("password");
		
		LoginService loginService = new LoginServiceImpl();
		Person p  = loginService.getRole(uname, pass);
		if (p!=null) {
			pr.print("Success");
			HttpSession session = req.getSession(true);
			session.setAttribute("uname", p.getName());
			session.setAttribute("pass", p.getPass());
			session.setAttribute("role", p.getRole());
			
			if(p.getRole().equals("admin")){
				RequestDispatcher rd = req.getRequestDispatcher("admin.html");
				rd.forward(req, res);
			}else {
				RequestDispatcher rd = req.getRequestDispatcher("user.html");
				rd.forward(req, res);
			}
		}
	}
}
