package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;
import com.demo.service.UserService;
import com.demo.service.UserServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.server.ServerEndpoint;

public class DeleteFromCart extends HttpServlet{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		UserService us = new UserServiceImpl();
		HttpSession s = req.getSession();
		int id = Integer.parseInt(req.getParameter("btn"));
		String name = (String) s.getAttribute("uname");
		us.removeFromBucket(name,id);
		List<Product> ans = us.showMyBucket(name);
		req.setAttribute("u", name);
		req.setAttribute("products", ans);
		RequestDispatcher rd = req.getRequestDispatcher("deleteFromCart.jsp");
		rd.forward(req, resp);
	}
	

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
