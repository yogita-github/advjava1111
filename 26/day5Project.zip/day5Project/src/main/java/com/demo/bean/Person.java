package com.demo.bean;

import java.time.LocalDate;
import java.util.Date;

public class Person {
    private String name;
    private String pass;
    private LocalDate dob;
    private String role;

    public Person(String name, String pass,LocalDate d ,String role) {
        this.name = name;
        this.pass = pass;
        this.dob=d;
        this.role = role;
    }
    public Person(String name, String pass,String role) {
        this.name = name;
        this.pass = pass;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public LocalDate getDob() {
        return dob;
    }

    public void setDate(LocalDate date) {
        this.dob=date;
    }
    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}