package com.demo.servlet;

public class Login extends http{

}
