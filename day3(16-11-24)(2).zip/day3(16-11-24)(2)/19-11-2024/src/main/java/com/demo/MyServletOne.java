package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MyServletOne extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.setContentType("text/html");
		PrintWriter pr = res.getWriter();
		String name = req.getParameter("userName");
		String pass = req.getParameter("pass");
		if(name.equals("user") && pass.equals("user")) {
			pr.print("login Successfull..");
		}else {
			pr.print("login Failed..");
		}
	}
}
