package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Add extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("<h1>Hello from Myfirst servlet</h1>");
		out.println("</body></html>");
		String num1 = request.getParameter("num1");
		String num2 = request.getParameter("num2");
		int sum = Integer.parseInt(num1)+Integer.parseInt(num2);
		out.print("<h1>sum</h1>" + sum);
	
	}
}
