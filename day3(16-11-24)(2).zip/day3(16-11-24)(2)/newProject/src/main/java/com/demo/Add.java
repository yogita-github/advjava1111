package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Add extends HttpServlet {
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException {
		res.setContentType("text/html");
		PrintWriter pr = res.getWriter();
		String n1 = req.getParameter("number1");
		String n2 = req.getParameter("number1");
		int ans = Integer.parseInt(n2) + Integer.parseInt(n1);
		pr.print("<h1> ans is : </h1>" + ans);
	}
}
