package com.demo.servlets;

public class TotalServlet {

}
