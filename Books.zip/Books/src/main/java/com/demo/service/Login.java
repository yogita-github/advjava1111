package com.demo.service;

public interface Login {

	boolean getUser(String username, String password);

}
