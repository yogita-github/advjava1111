package com.demo.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.beans.Course;
import com.demo.beans.Faculty;

public class TestOTO {
	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session s = sf.openSession();
		Transaction tr = s.beginTransaction();
		Course c1= new Course(1,"html",30);
		Faculty f1 = new Faculty(2,"xxx","yyyy",c1);
		s.save(c1);
		s.save(f1);
		tr.commit();
		s.close();
		sf.close();
	}


}
