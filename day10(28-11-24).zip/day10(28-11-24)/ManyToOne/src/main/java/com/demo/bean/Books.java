package com.demo.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ManyBooks")
public class Books {
	@Id
	private int bid;
	private String bname;
	private int price;
	@ManyToOne
	private Student s;
	public Books() {
	}
	public Books(int bid, String bname, int price, Student s) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.price = price;
		this.s = s;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Student getS() {
		return s;
	}
	public void setS(Student s) {
		this.s = s;
	}
	@Override
	public String toString() {
		return "Books [bid=" + bid + ", bname=" + bname + ", price=" + price + ", s=" + s + "]";
	}
	

}
