package com.demo.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.bean.Books;
import com.demo.bean.Student;

public class TestMO {
	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
				
		Student s1 = new Student();
		s1.setSid(1);
		s1.setSname("Yogesh");
		s1.setAddress("Amravati");
		Books b1=new Books(1,"Anime",56,s1);
		Books b2=new Books(2,"Boxing",400,s1);
		Set<Books> b = new HashSet();
		 b.add(b1);
		 b.add(b2);
		sess.save(s1);
		sess.save(b1);
		sess.save(b2);
		tr.commit();
		sess.close();
		sf.close();
	}
}
