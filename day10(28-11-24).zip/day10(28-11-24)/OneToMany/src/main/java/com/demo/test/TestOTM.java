package com.demo.test;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.beans.Course;
import com.demo.beans.Faculty;

public class TestOTM {
	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session s = sf.openSession();
		Transaction tr = s.beginTransaction();
		Course c1= new Course(1,"html",30);
		Course c2= new Course(2,"javascript",60);
		
		Faculty f1 = new Faculty(2,"xxx","yyyy",c1);
		Faculty f2 = new Faculty(3,"xaaaax","yybbbbyy",c1);
		Faculty f3 = new Faculty(5,"huhh","drrddr",c2);
		Faculty f4 = new Faculty(6,"iiiii","zzzz",c2);
		
		s.save(c1);
		s.save(c2);
		s.save(f1);
		s.save(f2);
		s.save(f3);
		s.save(f4);
		
		tr.commit();
		s.close();
		sf.close();
	}


}
