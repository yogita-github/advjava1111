package com.demo.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="FacultyZZ")
public class Faculty {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String fname;
	private String address;
	@ManyToOne
	private Course c1;
	
	public Faculty() {
	}
	public Faculty(int id, String fname, String address, Course c1) {
		this.id = id;
		this.fname = fname;
		this.address = address;
		this.c1 = c1;
	}
	public Faculty(String fname, String address, Course c1) {
		this.fname = fname;
		this.address = address;
		this.c1 = c1;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Course getC1() {
		return c1;
	}
	public void setC1(Course c1) {
		this.c1 = c1;
	}
	@Override
	public String toString() {
		return "Faculty [id=" + id + ", fname=" + fname + ", address=" + address  + ", c1=" + c1 + "]" ;
	}
	
}
