package com.demo.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "CourseStud1")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cid;

    private String cname; 
    private int duration;

    @ManyToMany
    private List<Student> sList; 

    public Course() {}

    public Course(int cid, String cname, int duration, List<Student> sList) {
        this.cid = cid;
        this.cname = cname;
        this.duration = duration;
        this.sList = sList;
    }

    public Course(String cname, int duration, List<Student> sList) {
        this.cname = cname;
        this.duration = duration;
        this.sList = sList;
    }

    public int getCid() {
        return cid; 
    }

    public void setCid(int cid) {
        this.cid = cid; 
    }

    public String getCname() {
        return cname; 
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public int getDuration() {
        return duration; 
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public List<Student> getsList() {
        return sList; 
    }

    public void setsList(List<Student> sList) {
        this.sList = sList;
    }

    public String toString() {
        return "Course [cid=" + cid + ", cname=" + cname + ", duration=" + duration ;
    }   
}