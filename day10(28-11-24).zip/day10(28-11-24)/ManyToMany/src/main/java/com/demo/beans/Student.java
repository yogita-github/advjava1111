package com.demo.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "StudTable1")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int sid; 

    private String sname;
    private int marks; 

    @ManyToMany(mappedBy = "sList") 
    private List<Course> cList; 

    public Student() {}

    public Student(int sid, String sname, int marks, List<Course> cList) {
        this.sid = sid;
        this.sname = sname;
        this.marks = marks;
        this.cList = cList;
    }

    public Student(String sname, int marks, List<Course> cList) {
        this.sname = sname;
        this.marks = marks;
        this.cList = cList;
    }

    public int getSid() {
        return sid; 
    }

    public void setSid(int sid) {
        this.sid = sid; 
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public int getMarks() {
        return marks; 
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public List<Course> getcList() {
        return cList;
    }

    public void setcList(List<Course> cList) {
        this.cList = cList;
    }

    public String toString() {
        return "Student [sid=" + sid + ", sname=" + sname + ", marks=" + marks + ", cList=" + cList + "]";
    }
    
    // Potential Error Comment:
    // Ensure that the Course class is also annotated with @Entity and properly manages the 
    // relationship back to the Student class. If the mapping is not set up correctly, 
    // Hibernate may not handle the persistence of the many-to-many relationship properly.
}