package com.demo.test;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.beans.Course;
import com.demo.beans.Student;

public class TestMTM {
    public static void main(String[] args) {

        SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = sf.openSession();
        Transaction tr = session.beginTransaction();

        List<Course> s1Course = new ArrayList<Course>();
        List<Course> s2Course = new ArrayList<Course>();
        List<Student> c1Student = new ArrayList<Student>();
        List<Student> c2Student = new ArrayList<Student>();

        Student student1 = new Student(1, "Yogita", 10, s1Course); // Negative marks might be an issue
        Student student2 = new Student(2, "Me", 100, s2Course);
        Course course1 = new Course(1, "JAVAAAAA", 10000, c1Student);
        Course course2 = new Course(2, "Python", 1, c2Student);

        s2Course.add(course1); 
        s1Course.add(course2); 
        s1Course.add(course1);  
        c1Student.add(student2); 
        c1Student.add(student1); 
        c2Student.add(student1); 

        student1.setcList(s1Course);
        student2.setcList(s2Course);
        
        course1.setsList(c1Student);
        course2.setsList(c2Student);

        session.save(student1);
        session.save(student2);

        session.save(course2);
        session.save(course1);
        
        Student one = session.get(Student.class , 1);
        System.out.println(one);
        tr.commit(); 
        session.close(); 
        sf.close(); 
    }
}