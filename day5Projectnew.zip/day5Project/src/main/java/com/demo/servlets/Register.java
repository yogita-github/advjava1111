package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpRequest;

import com.demo.service.UserRegistration;
import com.demo.service.UserRegistrationImpl;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Register extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter pr = response.getWriter();
		String uname = request.getParameter("username");
		String pass =request.getParameter("password");
		String dob = request.getParameter("dob");
		UserRegistration userRegistration = new UserRegistrationImpl();
		boolean status = userRegistration.addNewUser(uname, pass, dob);
		if(status) {
			pr.print("<h1>Registration successfull</h1>");
		}else {
			pr.print("<h1>Operation failed </h1>");
		}
	}

}
