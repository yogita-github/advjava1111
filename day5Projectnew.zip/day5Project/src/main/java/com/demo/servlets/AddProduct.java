package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;



import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class AddProduct extends HttpServlet{
	
   public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
	   response.setContentType("text/html");
	   PrintWriter out=response.getWriter();
	   
	   HttpSession sess=request.getSession();
	   String role=(String)sess.getAttribute("role");
	   if(role!=null && role.equals("admin")) {

		   String pname=request.getParameter("pname");
		   int qty=Integer.parseInt(request.getParameter("qty")); 
		   int price=Integer.parseInt(request.getParameter("price")); 
		   double discount = Double.parseDouble(request.getParameter("dis"));
		   String desc = request.getParameter("desc");
		   
		   Product p=new Product(pname,qty,price,(discount*0.01),desc);
		   ProductService pservice=new ProductServiceImpl();
		   
		   boolean status=pservice.addProduct(p);
		   RequestDispatcher rd = request.getRequestDispatcher("products");
		   rd.forward(request, response);
	   }else {
		   out.println("Pls login to the application!!");
		   RequestDispatcher rd=request.getRequestDispatcher("login.html");
		   rd.include(request, response);
	   }
	   
	   
   }
   
   @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		doGet(req, resp);
	}
	
}
