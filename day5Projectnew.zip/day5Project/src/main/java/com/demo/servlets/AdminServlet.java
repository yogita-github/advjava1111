package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import com.demo.dao.DaoOperationImpl;
import com.demo.dao.DaoOperations;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AdminServlet extends HttpServlet{
	public void doPost(HttpServletRequest request ,HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter pr = response.getWriter();
		String val = request.getParameter("productAction");
	    Scanner sc = new Scanner(System.in);
	    DaoOperations daoOperations = new DaoOperationImpl();
	    
		switch (val) {
		case "add": {
			RequestDispatcher rd = request.getRequestDispatcher("addProduct.html");
			rd.forward(request, response);
			break;
		}
		case "delete":{
			RequestDispatcher rd = request.getRequestDispatcher("deleteProduct.jsp");
			rd.forward(request, response);	
			break;
		}
		case "sort":{
			RequestDispatcher rd = request.getRequestDispatcher("sortByPrice.jsp");
			rd.forward(request, response);
			break;
		}
		case "updateQuantity":{
			RequestDispatcher rd = request.getRequestDispatcher("updateQty.jsp");
			rd.forward(request, response);
			break;
		}
		case "updatePrice":{
			RequestDispatcher rd = request.getRequestDispatcher("updatePrice.jsp");
			rd.forward(request,response);
			break;
		}
		case "addDiscount":{
			RequestDispatcher rd = request.getRequestDispatcher("addDiscount.jsp");
			rd.forward(request,response);
			break;
		}
		case "showAll":{
			RequestDispatcher rd = request.getRequestDispatcher("/product");
			rd.forward(request, response);	
			break;
		}
		default:
			RequestDispatcher rd = request.getRequestDispatcher("admin.html");
			rd.forward(request, response);
			break;
		}
		
	}
	

}
