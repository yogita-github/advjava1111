package com.demo.service;

import com.demo.bean.Person;

public interface LoginService {
    Person getRole(String uName,String pass);
}